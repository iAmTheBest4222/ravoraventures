import React from 'react';
const Portfolio = () => {
  return (
    <div style={{padding: '4rem', textAlign: 'center'}}>
      <h1 style={{fontSize: '2rem', fontWeight: 'bold'}}>Portfolio</h1>
      <p>Portfolio content has been removed as per the latest site update.</p>
    </div>
  );
}

export default Portfolio;
